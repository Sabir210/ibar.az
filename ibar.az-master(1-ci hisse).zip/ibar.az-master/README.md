header - Nicat
axtarış - Cəfər, Nicat
scroll, footer - Sabir
2-ci səhifə kalkulyatora kimi - Cəlil
